-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema khayat
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema khayat
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `khayat` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `khayat` ;

-- -----------------------------------------------------
-- Table `khayat`.`design`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`design` (
  `DesignName` VARCHAR(50) NOT NULL,
  `Category` VARCHAR(45) NOT NULL,
  `DesignDate` VARCHAR(45) NOT NULL,
  `FabricType` VARCHAR(45) NOT NULL,
  `Price` DECIMAL(20,0) NOT NULL,
  PRIMARY KEY (`DesignName`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`customer` (
  `Phone` INT NOT NULL,
  `Name` VARCHAR(45) NULL DEFAULT NULL,
  `Address` VARCHAR(45) NULL DEFAULT NULL,
  `Email` VARCHAR(45) NULL DEFAULT NULL,
  `Password` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`Phone`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`admire`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`admire` (
  `CustomerPhone` INT NOT NULL,
  `DesignName` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`CustomerPhone`, `DesignName`),
  INDEX `DesignName` (`DesignName` ASC) VISIBLE,
  CONSTRAINT `admire_ibfk_2`
    FOREIGN KEY (`DesignName`)
    REFERENCES `khayat`.`design` (`DesignName`),
  CONSTRAINT `admire_ibfk_7`
    FOREIGN KEY (`CustomerPhone`)
    REFERENCES `khayat`.`customer` (`Phone`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`employee`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`employee` (
  `EmployeeID` INT NOT NULL,
  `Name` VARCHAR(45) NULL DEFAULT NULL,
  `Email` VARCHAR(45) NULL DEFAULT NULL,
  `Address` VARCHAR(45) NULL DEFAULT NULL,
  `Salary` VARCHAR(45) NULL DEFAULT NULL,
  `password` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`EmployeeID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`appointment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`appointment` (
  `EmployeeID` INT NOT NULL,
  `CustomerPhone` INT NOT NULL,
  `Notes` VARCHAR(200) NULL DEFAULT NULL,
  `Address` VARCHAR(100) NULL DEFAULT NULL,
  `DateTime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`EmployeeID`, `CustomerPhone`),
  INDEX `CustomerPhone` (`CustomerPhone` ASC) VISIBLE,
  CONSTRAINT `appointment_ibfk_1`
    FOREIGN KEY (`EmployeeID`)
    REFERENCES `khayat`.`employee` (`EmployeeID`),
  CONSTRAINT `appointment_ibfk_3`
    FOREIGN KEY (`CustomerPhone`)
    REFERENCES `khayat`.`customer` (`Phone`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`survey`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`survey` (
  `SurveyID` INT NOT NULL,
  `Score` VARCHAR(45) NULL DEFAULT NULL,
  `Feedback` VARCHAR(45) NULL DEFAULT NULL,
  `completionDate` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`SurveyID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`avaliable`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`avaliable` (
  `SurveyNumber` INT NOT NULL,
  `CustomerPhone` INT NULL DEFAULT NULL,
  PRIMARY KEY (`SurveyNumber`),
  INDEX `CustomerPhone` (`CustomerPhone` ASC) VISIBLE,
  CONSTRAINT `avaliable_ibfk_1`
    FOREIGN KEY (`SurveyNumber`)
    REFERENCES `khayat`.`survey` (`SurveyID`),
  CONSTRAINT `avaliable_ibfk_3`
    FOREIGN KEY (`CustomerPhone`)
    REFERENCES `khayat`.`customer` (`Phone`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`branch`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`branch` (
  `BranchID` INT NOT NULL,
  `Address` VARCHAR(45) NULL DEFAULT NULL,
  `PhoneNumber` INT NULL DEFAULT NULL,
  PRIMARY KEY (`BranchID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`measurement`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`measurement` (
  `MeasurementID` INT NOT NULL,
  `Waist` DECIMAL(10,0) NULL DEFAULT NULL,
  `Bust` DECIMAL(10,0) NULL DEFAULT NULL,
  `Neck` DECIMAL(10,0) NULL DEFAULT NULL,
  `Hips` DECIMAL(10,0) NULL DEFAULT NULL,
  `Shoulder` DECIMAL(10,0) NULL DEFAULT NULL,
  `Leg` DECIMAL(10,0) NULL DEFAULT NULL,
  `Height` DECIMAL(10,0) NULL DEFAULT NULL,
  `ArmLength` DECIMAL(10,0) NULL DEFAULT NULL,
  PRIMARY KEY (`MeasurementID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`customer_measurement`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`customer_measurement` (
  `CustomerPhone` INT NOT NULL,
  `MeasurementID` INT NOT NULL,
  PRIMARY KEY (`CustomerPhone`, `MeasurementID`),
  INDEX `MeasurementID` (`MeasurementID` ASC) VISIBLE,
  CONSTRAINT `customer_measurement_ibfk_1`
    FOREIGN KEY (`MeasurementID`)
    REFERENCES `khayat`.`measurement` (`MeasurementID`),
  CONSTRAINT `customer_measurement_ibfk_2`
    FOREIGN KEY (`CustomerPhone`)
    REFERENCES `khayat`.`customer` (`Phone`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`designer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`designer` (
  `DesignerID` INT NOT NULL,
  `Name` VARCHAR(45) NULL DEFAULT NULL,
  `Style` VARCHAR(45) NULL DEFAULT NULL,
  `Phone` INT NULL DEFAULT NULL,
  `Email` VARCHAR(45) NULL DEFAULT NULL,
  `Password` VARCHAR(45) NULL DEFAULT NULL,
  `Address` VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (`DesignerID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`make`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`make` (
  `DesignerID` INT NOT NULL,
  `DesignName` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`DesignerID`, `DesignName`),
  INDEX `DesignName` (`DesignName` ASC) VISIBLE,
  CONSTRAINT `make_ibfk_1`
    FOREIGN KEY (`DesignerID`)
    REFERENCES `khayat`.`designer` (`DesignerID`),
  CONSTRAINT `make_ibfk_2`
    FOREIGN KEY (`DesignName`)
    REFERENCES `khayat`.`design` (`DesignName`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`manages`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`manages` (
  `ManagerID` INT NOT NULL,
  `EmployeeID` INT NOT NULL,
  PRIMARY KEY (`ManagerID`, `EmployeeID`),
  INDEX `EmployeeID` (`EmployeeID` ASC) VISIBLE,
  CONSTRAINT `manages_ibfk_1`
    FOREIGN KEY (`ManagerID`)
    REFERENCES `khayat`.`employee` (`EmployeeID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`mentions`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`mentions` (
  `EmployeeID` INT NOT NULL,
  `SurveyNumber` INT NOT NULL,
  PRIMARY KEY (`EmployeeID`, `SurveyNumber`),
  INDEX `SurveyNumber` (`SurveyNumber` ASC) VISIBLE,
  CONSTRAINT `mentions_ibfk_1`
    FOREIGN KEY (`EmployeeID`)
    REFERENCES `khayat`.`employee` (`EmployeeID`),
  CONSTRAINT `mentions_ibfk_3`
    FOREIGN KEY (`SurveyNumber`)
    REFERENCES `khayat`.`survey` (`SurveyID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`order_process`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`order_process` (
  `DesignID` INT NULL DEFAULT NULL,
  `OrderID` INT NOT NULL,
  `Color` VARCHAR(45) NULL DEFAULT NULL,
  `Speed` VARCHAR(45) NULL DEFAULT NULL,
  `ArrivalDate` DATETIME NULL DEFAULT NULL,
  `Status` VARCHAR(45) NULL DEFAULT NULL,
  `ExpectedArrivalDate` DATETIME NULL DEFAULT NULL,
  `OrderDate` DATETIME NULL DEFAULT NULL,
  `modification` VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (`OrderID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`placed`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`placed` (
  `CustomerPhone` INT NOT NULL,
  `OrderID` INT NOT NULL,
  PRIMARY KEY (`CustomerPhone`, `OrderID`),
  INDEX `OrderID` (`OrderID` ASC) VISIBLE,
  CONSTRAINT `placed_ibfk_1`
    FOREIGN KEY (`CustomerPhone`)
    REFERENCES `khayat`.`customer` (`Phone`),
  CONSTRAINT `placed_ibfk_3`
    FOREIGN KEY (`OrderID`)
    REFERENCES `khayat`.`order_process` (`OrderID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`processes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`processes` (
  `BranchID` INT NOT NULL,
  `OrderID` INT NOT NULL,
  PRIMARY KEY (`BranchID`, `OrderID`),
  INDEX `OrderID` (`OrderID` ASC) VISIBLE,
  CONSTRAINT `processes_ibfk_5`
    FOREIGN KEY (`BranchID`)
    REFERENCES `khayat`.`branch` (`BranchID`),
  CONSTRAINT `processes_ibfk_6`
    FOREIGN KEY (`OrderID`)
    REFERENCES `khayat`.`order_process` (`OrderID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `khayat`.`works_at`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `khayat`.`works_at` (
  `EmployeeID` INT NOT NULL,
  `BranchID` INT NOT NULL,
  PRIMARY KEY (`EmployeeID`, `BranchID`),
  INDEX `BranchID` (`BranchID` ASC) VISIBLE,
  CONSTRAINT `works_at_ibfk_1`
    FOREIGN KEY (`BranchID`)
    REFERENCES `khayat`.`branch` (`BranchID`),
  CONSTRAINT `works_at_ibfk_2`
    FOREIGN KEY (`EmployeeID`)
    REFERENCES `khayat`.`employee` (`EmployeeID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
