INSERT INTO measurement( MeasurementID,Waist ,Bust,Neck, Hips, Shoulder, Leg,Height, ArmLength)
VALUES
	(6,	30.5,	34.5,	12.5,	36.5,	15.5,	32.5,	64,	22.5 ),
    (7,	32.0,	36.0,	13.0,	38.0,	16.0,	33.0,	66,	23.0),
    (9,	33.5,	37.5,	13.5,	39.5,	16.5,	34.5,	68,	23.5),
    (10,	35.0,	39.0,	14.0,	41.0,	17.0,	36.0,	70,	24.0),
    (5,	36.5,	40.5,	14.5,	42.5,	17.5,	37.5,	72,	24.5);


INSERT INTO design( DesignName,Category,DesignDate,FabricType,Price)
VALUES
('design1', 'Dresses', '2022-05-01', 'Cotton', 49.99),
('design2', 'Outerwear', '2021-11-15', 'Wool', 149.99),
('desging3', 'Bottoms', '2022-02-28', 'Denim', 79.99),
('desgin4', 'Tops', '2022-03-20', 'Silk', 89.99),
('desting5', 'Tops', '2022-01-10', 'Cotton', 29.99);
