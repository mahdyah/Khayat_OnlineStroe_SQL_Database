
# Khayat

This project was build in MYsql workbench cummunity 8.0, Version 8.0.32, 64 bits.
There is a file of all scripts. The file has the code for creating all the tables, and entities.
Also, there is another file that has the script for inserting some dummy data to some of the tables.
 To execute the code, you will need to create a new schema and open a query, copy and paste the script and execute. The script will create all the tables, entities, and constrians.
Inserting data process, would be same as the creating tables. There could be differnt ways of accomplishing it, but it could also be done by just copy and pasting the script and executing.  

