
-- Create a view for all of the designs that a particular customer likes.
SELECT des.DesignName,des.Category,des.DesignDate,des.FabricType,des.Price
FROM design des,admire a,customer c
WHERE c.Phone=111111111 and a.CustomerPhone=c.Phone and des.DesignName=a.DesignName;


-- Customers will be able to access a view of designs for a particular category and/or designer
SELECT *
FROM khayat.design
WHERE Category='Jackets';

-- Customers will be able to access a view of designs for a particular category and/or designer
SELECT d.Name,des.DesignName,des.Category,des.DesignDate,des.FabricType,des.Price
FROM design des, designer d, make m
WHERE d.Name="John Smith" and d.DesignerID=m.DesignerID and m.DesignName=des.DesignName;


-- Managers will be able to view surveys that mention employees that they manage.
SELECT * 
FROM mentions me, manages ma, survey s 
WHERE ma.ManagerID=1 and ma.EmployeeID=me.EmployeeID and s.SurveyID=me.surveyNumber;

-- A manager can view all of the employees that work at the same branch as them.
SELECT e.Name
FROM Works_at w
INNER JOIN Employee e ON w.EmployeeID = e.EmployeeID
WHERE w.BranchID = (SELECT BranchID FROM Works_at WHERE EmployeeID = 11);

-- Customers can check the status of their orders 
SELECT c.Name, o.OrderID, o.Status
FROM order_process o,customer c, placed p
WHERE c.Phone=111111111 and c.Phone=p.CustomerPhone and p.OrderID=o.OrderID;

--  Customers should be able to schedule appointments with employees at a branch they select || Employees can also schedule appointments
INSERT INTO khayat.appointment (EmployeeID, CustomerPhone, Notes, Address, DateTime) 
VALUES
(2, 111111111, 'Notes1', 'New address', '2022-01-01 10:00:00');


-- Allow 2 customers to place an order containing all of their items from the cart, their choice of expedited or regular speed, and possible discount code in their cart
INSERT INTO khayat.order_process (DesignName, OrderID, Color, Speed, ArrivalDate, Status, ExpectedArrivalDate, OrderDate, modification)
VALUES
('design4', 2023, 'blue', 'Fast', '2023-04-19 10:00:00', 'Pending', '2023-04-25 10:00:00', '2023-04-18 10:00:00', 'None');






